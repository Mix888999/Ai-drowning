import cv2
from flask import Flask, render_template, Response, request, jsonify
import paho.mqtt.client as mqtt
import threading

app = Flask(__name__)

current_status = 0  # 0=ซ่อน, 1=โชว์, 2=โชว์+เสียง

# --- ใช้วีดีโอแทนภาพนิ่ง ---
CAM1_FILE = "video1.mp4"
CAM2_FILE = "video2.mp4"

# --- MQTT setup ---
MQTT_BROKER = "10.0.15.249"  # เปลี่ยนเป็น IP broker ของคุณ
MQTT_PORT = 1883
MQTT_TOPIC = "server/esp32"

def on_connect(client, userdata, flags, rc):
    print("Connected to MQTT broker with result code", rc)
    client.subscribe(MQTT_TOPIC)

def on_message(client, userdata, msg):
    global current_status
    try:
        payload = int(msg.payload.decode())
        if payload in [0, 1, 2, 4]:
            current_status = payload
            print("Status updated to:", current_status)
    except ValueError:
        print("Invalid payload:", msg.payload)

mqtt_client = mqtt.Client()
mqtt_client.on_connect = on_connect
mqtt_client.on_message = on_message
mqtt_client.connect(MQTT_BROKER, MQTT_PORT, 60)

# เริ่ม MQTT loop ใน thread แยก
def mqtt_loop():
    mqtt_client.loop_forever()

threading.Thread(target=mqtt_loop, daemon=True).start()


# --- ฟังก์ชัน generator สำหรับวีดีโอ ---
def generate_frames_video(filepath):
    cap = cv2.VideoCapture(filepath)
    if not cap.isOpened():
        raise FileNotFoundError(f"ไม่พบไฟล์วีดีโอ: {filepath}")

    while True:
        ret, frame = cap.read()
        if not ret:
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)  # เล่นวนกลับต้นวีดีโอ
            continue
        ret, buffer = cv2.imencode('.jpg', frame)
        frame_bytes = buffer.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')

# --- Flask routes ---
@app.route('/')
def index():
    return render_template('page1.html')

@app.route('/video_feed1')
def video_feed1():
    return Response(generate_frames_video(CAM1_FILE),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/video_feed2')
def video_feed2():
    return Response(generate_frames_video(CAM2_FILE),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/button-click', methods=['POST'])
def handle_button_click():
    global current_status
    current_status = 0
    return jsonify({'message': 'ปุ่มถูกคลิกเรียบร้อย!'})

@app.route('/get_status')
def get_status():
    return jsonify({'status': current_status})

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True)
