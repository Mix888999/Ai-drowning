import cv2
from flask import Flask, render_template, Response, request, jsonify # เพิ่ม jsonify เข้ามา

app = Flask(__name__)

# Function to generate video frames
def generate_frames():
    # 0 for the default webcam
    camera = cv2.VideoCapture(0)  
    if not camera.isOpened():
        print("Error: Could not open video device.")
        return
        
    while True:
        # Read a frame from the camera
        success, frame = camera.read()
        if not success:
            break
        else:
            # Open local windows
            cv2.imshow("Camera", frame)
            if cv2.waitKey(10) & 0xFF == ord("q"):
                break

            # Encode the frame to a JPEG image
            ret, buffer = cv2.imencode('.png', frame)
            frame_bytes = buffer.tobytes()
            
            # Yield the frame in a multipart format
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
    camera.release()
    cv2.destroyAllWindows()

# Route for the main page
@app.route('/')
def index():
    # Render the HTML template
    return render_template('page1.html')

# Route for the video stream
@app.route('/video_feed')
def video_feed():
    # Return the stream as a response
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

# Route ใหม่สำหรับจัดการการคลิกปุ่ม
@app.route('/button-click', methods=['POST'])
def handle_button_click():
    data = request.json
    print(f"Received from client: {data['action']}")
    
    # ส่งข้อความยืนยันกลับไปให้หน้าเว็บ
    return jsonify({'message': 'Button was clicked successfully!'})

if __name__ == '__main__':
    # Run the application on all available IPs
    app.run(host='0.0.0.0', debug=True)