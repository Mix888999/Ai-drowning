import cv2
from flask import Flask, render_template, Response, request, jsonify

app = Flask(__name__)

current_status = 2  # 0=ซ่อน, 1=โชว์, 2=โชว์+เสียง

# URL ของกล้อง IP
CAM1_URL = "rtsp://admin:Hikvisionwt@192.168.1.64:554/Streaming/Channels/101"
CAM2_URL = "rtsp://admin:Hikvisionwt@192.168.1.63:554/Streaming/Channels/101"

# ฟังก์ชัน generator สำหรับกล้อง 1
def generate_frames_cam1():
    camera = cv2.VideoCapture(CAM1_URL)
    if not camera.isOpened():
        print("Error: Cannot open camera 1")
        return
    try:
        while True:
            success, frame = camera.read()
            if not success:
                break
            ret, buffer = cv2.imencode('.jpg', frame)
            frame_bytes = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
    finally:
        camera.release()

# ฟังก์ชัน generator สำหรับกล้อง 2
def generate_frames_cam2():
    camera = cv2.VideoCapture(CAM2_URL)
    if not camera.isOpened():
        print("Error: Cannot open camera 2")
        return
    try:
        while True:
            success, frame = camera.read()
            if not success:
                break
            ret, buffer = cv2.imencode('.jpg', frame)
            frame_bytes = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
    finally:
        camera.release()

# หน้าแรก
@app.route('/')
def index():
    return render_template('page1.html')

# Routes วิดีโอสตรีม
@app.route('/video_feed1')
def video_feed1():
    return Response(generate_frames_cam1(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/video_feed2')
def video_feed2():
    return Response(generate_frames_cam2(), mimetype='multipart/x-mixed-replace; boundary=frame')

# ปุ่ม "ปลอดภัย"
@app.route('/button-click', methods=['POST'])
def handle_button_click():
    global current_status
    data = request.json
    current_status = 0
    return jsonify({'message': 'ปุ่มถูกคลิกเรียบร้อย!'})

# ดึงสถานะ
@app.route('/get_status')
def get_status():
    return jsonify({'status': current_status})

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True)
