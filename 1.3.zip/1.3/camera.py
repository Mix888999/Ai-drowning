import cv2
from flask import Flask, render_template, Response, request, jsonify

app = Flask(__name__)

# ตัวแปรสถานะ 0(สีเขียว), 1(สีเหลือง), 2(สีแดง)
# สถานะเริ่มต้นเป็น 2 เพื่อให้เล่นเสียงทันทีที่โหลดหน้าเว็บ
current_status = 0

# Function to generate video frames
def generate_frames():
    # 0 for the default webcam
    camera = cv2.VideoCapture(0)  
    if not camera.isOpened():
        print("Error: Could not open video device.")
        return
        
    while True:
        # Read a frame from the camera
        success, frame = camera.read()
        if not success:
            break
        else:
            # Encode the frame to a JPEG image
            ret, buffer = cv2.imencode('.png', frame)
            frame_bytes = buffer.tobytes()          
            
            # Yield the frame in a multipart format
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
    camera.release()

# Route for the main page
@app.route('/')
def index():
    # Render the HTML template
    return render_template('page1.html')

# Route for the video stream
@app.route('/video_feed')
def video_feed():
    # Return the stream as a response
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

# Route สำหรับจัดการการคลิกปุ่ม
@app.route('/button-click', methods=['POST'])
def handle_button_click():
    global current_status
    data = request.json
    print(f"ได้รับคำขอจาก client: {data['action']}")
    
    # เมื่อคลิกปุ่ม ให้เปลี่ยนสถานะเป็น 0
    current_status = 0
    print(f"อัปเดตสถานะเป็น: {current_status}")
    
    # ส่งข้อความยืนยันกลับไปให้หน้าเว็บ
    return jsonify({'message': 'ปุ่มถูกคลิกเรียบร้อย!'})

# Route สำหรับส่งสถานะให้หน้าเว็บ
@app.route('/get_status')
def get_status():
    global current_status
    # ส่งค่าสถานะปัจจุบันในรูปแบบ JSON
    return jsonify({'status': current_status})
    
# Route สำหรับตั้งค่าสถานะด้วยตนเอง
@app.route('/set_status', methods=['POST'])
def set_status():
    global current_status
    data = request.json
    if 'status' in data:
        new_status = data['status']
        if new_status in [0, 1, 2]:
            current_status = new_status
            print(f"Manually updated status to: {current_status}")
            return jsonify({'message': f'Status updated to {current_status}'})
    return jsonify({'message': 'Invalid status provided'}), 400

if __name__ == '__main__':
    # Run the application on all available IPs
    app.run(host='0.0.0.0', debug=True)
