# publisher.py
import paho.mqtt.client as mqtt
import time

broker = "10.0.13.36"  # หรือใช้ IP ของ notebook
port = 1883
topic_web = "server/web"
topic_esp32 = "server/esp32"

client = mqtt.Client()
client.connect(broker, port, 60)

msg = 0
while True:
    client.publish(topic_esp32, msg)
    print("Sent:", msg)
    time.sleep(1)
